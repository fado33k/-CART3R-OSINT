let kind = "domain";
let lastResult = null;
const config = {
  domain: {label:"Domaine à auditer", placeholder:"exemple.fr", hint:"DNS, certificat TLS et en-têtes HTTP de sécurité."},
  email: {label:"Votre adresse e-mail", placeholder:"vous@exemple.fr", hint:"Format et résolution du domaine. Aucune base de fuites n'est interrogée."},
  username: {label:"Votre pseudonyme", placeholder:"mon_pseudo", hint:"Liens de recherche manuelle pour vérifier votre propre présence publique."}
};
const $ = selector => document.querySelector(selector);

document.querySelectorAll(".tab").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(tab => tab.classList.remove("active"));
  button.classList.add("active");
  kind = button.dataset.kind;
  $("#fieldLabel").textContent = config[kind].label;
  $("#value").placeholder = config[kind].placeholder;
  $("#hint").textContent = config[kind].hint;
  $("#error").textContent = "";
}));

$("#auditForm").addEventListener("submit", async event => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  button.textContent = "ANALYSE EN COURS…";
  $("#error").textContent = "";
  try {
    const response = await fetch("/api/audit", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({kind, value: $("#value").value.trim()})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Une erreur est survenue.");
    lastResult = data;
    $("#resultTitle").textContent = data.title;
    $("#scope").textContent = data.scope;
    $("#timestamp").textContent = "HORODATAGE : " + data.checked_at;
    const container = $("#items");
    container.replaceChildren();
    data.items.forEach(item => {
      const card = document.createElement("article");
      card.className = "item";
      const top = document.createElement("div");
      top.className = "item-top";
      const label = document.createElement("span");
      label.textContent = item.label;
      const status = document.createElement("span");
      status.className = "pill";
      status.textContent = item.status;
      const detail = document.createElement("div");
      detail.className = "detail";
      if (item.status === "LIEN") {
        const link = document.createElement("a");
        link.href = item.detail;
        link.textContent = item.detail;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        detail.append(link);
      } else detail.textContent = item.detail;
      top.append(label, status);
      card.append(top, detail);
      container.append(card);
    });
    $("#results").hidden = false;
    $("#results").scrollIntoView({behavior:"smooth", block:"start"});
  } catch (error) {
    $("#error").textContent = error.message;
  } finally {
    button.disabled = false;
    button.innerHTML = "LANCER L'AUDIT <span>↗</span>";
  }
});

$("#copy").addEventListener("click", async () => {
  if (!lastResult) return;
  try {
    await navigator.clipboard.writeText(JSON.stringify(lastResult, null, 2));
    $("#copy").textContent = "COPIÉ ✓";
    setTimeout(() => $("#copy").textContent = "COPIER JSON", 1600);
  } catch {
    $("#copy").textContent = "COPIE IMPOSSIBLE";
  }
});
