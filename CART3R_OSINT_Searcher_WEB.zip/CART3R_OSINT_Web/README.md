# CART3R.JAILBREAK — OSINT Searcher (édition Web)

Application web locale en français, avec interface noire et rouge.

## Modules
- **Domaine** : résolution DNS, validation TLS et présence de cinq en-têtes HTTP de sécurité.
- **Mon e-mail** : vérification syntaxique et résolution DNS du domaine. Ne prétend pas consulter des bases de fuites.
- **Mon pseudo** : génère des liens vers des moteurs/sites publics pour une vérification manuelle de votre propre pseudonyme.
- **Rapport** : affichage et copie des résultats JSON.

## Installation
Python 3.10+ recommandé.

```bash
python -m venv .venv
```

Windows :
```powershell
.venv\Scripts\activate
```

macOS / Linux :
```bash
source .venv/bin/activate
```

Installer les dépendances :
```bash
pip install -r requirements.txt
```

Démarrer :
```bash
python app.py
```

Ouvrir ensuite **http://127.0.0.1:5000** dans le navigateur.

## Déploiement
Le serveur est configuré pour écouter uniquement sur `127.0.0.1`. Pour un déploiement public, utilisez un hébergement sécurisé avec HTTPS, un serveur WSGI de production, des mises à jour régulières, des limites de requêtes et une politique de confidentialité adaptée. Ne publiez pas le serveur de développement Flask tel quel.

## Limites et utilisation responsable
- N'auditez que les domaines que vous possédez ou pour lesquels vous avez une autorisation explicite.
- Les résultats sont indicatifs, pas un audit de sécurité exhaustif.
- Aucun mot de passe, code 2FA ou secret n'est demandé.
- Aucun scan de ports, contournement d'authentification, test de mots de passe ou aspiration de profils.
- Aucun outil de localisation, de recherche d'adresse personnelle ou d'identification de proches.
- Pour vérifier une éventuelle fuite de votre propre adresse, consultez directement https://haveibeenpwned.com/ et respectez les conditions du service.
